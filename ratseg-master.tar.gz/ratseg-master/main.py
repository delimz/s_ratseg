import os
import glob
import zipfile
import functools
import re

import numpy as np

import tensorflow as tf

from time import time

from models import *
from data import *
from losses import *
from augment import _augment
from layers import training

from argparse import ArgumentParser
import sys

def parsebool(x):
    return x in ['True','true','t','yes','y','yep','affirmative','yesplease','ya','oy','oui','ui','v','V','Vrai']


parser = ArgumentParser(prog="ratseg")

parser.add_argument('-m','--model-name',default='vanilla')
parser.add_argument('-t','--model-type',default='mnet') 
parser.add_argument('-s','--step-restore',default=None,help='The step at which the model must be restored')

'''  
Augmentation:

'''
parser.add_argument('--rotation',type=parsebool,default=True,
        help='perform random rotation of the image, true or false')

parser.add_argument('--flip',type=parsebool,default=True,
        help='perform random flip of the image, true or false')

parser.add_argument('--softmax',type=parsebool,default=False,
        help='use softmax instead of sigmoid and add a background class to the labels')

parser.add_argument('--residual',type=parsebool,default=True,
        help='add skip connections within blocks of convolution')

parser.add_argument('--offset',type=parsebool,default=True,
        help='overlap predictions to smooth the mask')

parser.add_argument('--do-train',type=parsebool,default=True,
        help='whether to train the algoritm')

parser.add_argument('--do-test',type=parsebool,default=True,
        help='whether to test the algoritm, needs opencv to resize images')


parser.add_argument('--cache',type=parsebool,default=False,
        help='whether to cache the images in memeory (useful if slow disk access)')

parser.add_argument('--brightness',type=float,default=0.1,
        help='max brightness delta to apply')

parser.add_argument('--hue',type=float,default=0.05,
        help='max hue delta to apply')

parser.add_argument('--saturation',type=float,default=0.3,
        help='max saturation delta to apply')

parser.add_argument('--contrast',type=float,default=0.1,
        help='max contrast delta to apply')

parser.add_argument('--learning-rate',type=float,default=0.001,
        help='learning rate for AdamOptimizer')

parser.add_argument('--momentum-decay',type=float,default=0.9,
        help='beta1 for AdamOptimizer')


'''
Model details:

-Type of activation

-Number of conv per block

-Use of residuals

-Size of the filters

-type of loss

'''

'''
Model parameter:

-Focal loss \gamma and \beta

-training step

'''

parser.add_argument('--epochs',type=int,default=5,
        help='maximum number of epochs to train')

parser.add_argument('--batch-size',type=int,default=5,
        help='batch size in each step')

parser.add_argument('--jobs',type=int,default=16,
        help='number of threads avalible')
parser.add_argument('--buff',type=int,default=50,
        help='prefetch buffer size')
'''
data information
'''

#parser.add_argument('--imgs-train',type=int,nargs='+',default=[514, 520,72938,73108,73193,73278,73363,85101,85356,85587,85772])
#parser.add_argument('--imgs-test',type=int,nargs='+',default=[526,85942,85322,85610])
parser.add_argument('--imgs-train',type=int,nargs='+',default=[1049959,1059806,1059822,2313561,2313567,2313573,2313581,2313589,2313595,2319535,2319541])
parser.add_argument('--imgs-val',type=int,nargs='+',default=[2319547,2319553,2319561,2319567])
parser.add_argument('--imgs-test',type=int,nargs='+',default=[2319573,2319579,2319587,2319595])

#parser.add_argument('--terms',type=int,nargs='+',default=[576, 584, 592, 568]) #gm l b d #560 = gc
parser.add_argument('--terms',type=int,nargs='+',default=[1012286,1012259,1012265,1012280]) #gm l b d #1012294 = gc

parser.add_argument('--datadir',type=str,default='tmp')

params = parser.parse_args(sys.argv[1:])

learning_rate=params.learning_rate

model_name=params.model_name
step_restore=params.step_restore

img_shape = (512, 512, 3)
batch_size = params.batch_size
epochs = params.epochs

imgs_train = params.imgs_train
imgs_val= params.imgs_val
imgs_test = params.imgs_test
terms= params.terms

datadir=params.datadir

def sortkey(x):
    sp=x.split('_')
    return int(sp[2])*100000+int(sp[3])
filenames=sorted(os.listdir("%s/crop/" % datadir),key=sortkey)

def startswith(x,l):
    for e in l:
        if x.startswith(str(e)):
            return True
    return False


train_filenames=[f[:-4] for f in filter(lambda x : startswith(x,imgs_train),filenames) ]
val_filenames=[f[:-4] for f in filter(lambda x : startswith(x,imgs_val),filenames)]
test_filenames=[f[:-4] for f in filter(lambda x : startswith(x,imgs_test),filenames)]

x_train_filenames = ["{}/crop/{}.jpg".format(datadir, x) for x in train_filenames]
y_train_filenames=[]
for i in range(len(terms)):
    y_train_filenames.append(["{}/{}/{}.png".format(datadir, terms[i],x) for x in train_filenames])

x_val_filenames = ["{}/crop/{}.jpg".format(datadir, x) for x in val_filenames]
y_val_filenames=[]
for i in range(len(terms)):
    y_val_filenames.append( ["{}/{}/{}.png".format(datadir, terms[i],x) for x in val_filenames])
    
x_test_filenames = ["{}/crop/{}.jpg".format(datadir, x) for x in test_filenames]
y_test_filenames=[]
for i in range(len(terms)):
    y_test_filenames.append( ["{}/{}/{}.png".format(datadir, terms[i],x) for x in test_filenames])

x_train_filenames=np.array(x_train_filenames)
y_train_filenames=np.array(y_train_filenames).transpose()
x_val_filenames=np.array(x_val_filenames)
y_val_filenames=np.array(y_val_filenames).transpose()
x_test_filenames=np.array(x_test_filenames)
y_test_filenames=np.array(y_test_filenames).transpose()

print(x_train_filenames.shape,y_train_filenames.shape,x_val_filenames.shape,y_val_filenames.shape,x_test_filenames.shape,y_test_filenames.shape)

tr_cfg = {
    'resize': [img_shape[0], img_shape[1]],
    'hue_delta': params.hue,
    'saturation_delta' : params.saturation,
    'brightness_delta' : params.brightness,
    'contrast_delta': params.contrast,
    'horizontal_flip': params.flip,
    'rotate': params.rotation,
    'hor_crop_range': 0.2,
    'vert_crop_range' : 0.2,
    'width_shift_range': 0,
    'height_shift_range': 0,
    'background_class' : params.softmax
}
tr_preprocessing_fn = functools.partial(_augment, **tr_cfg)

val_cfg = {
    'resize': [img_shape[0], img_shape[1]],
    'background_class' : params.softmax
}
val_preprocessing_fn = functools.partial(_augment, **val_cfg)
num_x=tf.placeholder(tf.int64,None)
handle = tf.placeholder(tf.string,shape=[])

dropout_factor = tf.placeholder(tf.float32,None)

if params.do_train:
 
    x_train_placeholder=tf.placeholder(np.array(x_train_filenames).dtype,[None])
    y_train_placeholder=tf.placeholder(np.array(y_train_filenames).dtype,[None,len(terms)])
    x_val_placeholder=tf.placeholder(np.array(x_val_filenames).dtype,[None])
    x_val_placeholder=tf.placeholder(np.array(x_val_filenames).dtype,[None,len(terms)])

    train_ds = get_baseline_dataset(x_train_placeholder,
                                    y_train_placeholder,
                                    num_x,
                                    tr_preprocessing_fn,
                                    batch_size=batch_size,
                                    threads=params.jobs,
                                    buff_size=params.buff,
                                    cache=params.cache)

    val_ds = get_baseline_dataset(x_train_placeholder,
                                  y_train_placeholder,
                                  num_x,
                                  val_preprocessing_fn,
                                  batch_size=batch_size,
                                  shuffle=false,
                                  threads=params.jobs,
                                  buff_size=params.buff)

else:
  
    x_train_placeholder=tf.placeholder(np.array(x_test_filenames).dtype,[None])
    y_train_placeholder=tf.placeholder(np.array(y_test_filenames).dtype,[None,len(terms)])
    x_val_placeholder=tf.placeholder(np.array(x_test_filenames).dtype,[None])
    x_val_placeholder=tf.placeholder(np.array(x_test_filenames).dtype,[None,len(terms)])
    
    offset=(0,0)
    test_cfg = {
        'resize':[img_shape[0], img_shape[1]],
        'offset_x' : offset[0],
        'offset_y' : offset[1],
        'background_class' : params.softmax
    }
    test_preprocessing_fn = functools.partial(_augment, **test_cfg)


    test_ds = get_baseline_dataset(x_train_placeholder,
                                  y_train_placeholder,
                                  num_x,
                                  test_preprocessing_fn,
                                  batch_size=batch_size,
                                  shuffle=False,
                                  threads=params.jobs,
                                  buff_size=params.buff)
    train_ds = test_ds
    val_ds = test_ds


global_step = tf.train.get_or_create_global_step()

with tf.variable_scope("train",reuse=tf.AUTO_REUSE):
    train_iterator = train_ds.make_initializable_iterator()
    val_iterator = val_ds.make_initializable_iterator()

    iterator = tf.data.Iterator.from_string_handle(
        handle, train_iterator.output_types,train_iterator.output_shapes)
    
    images,labels=iterator.get_next()

    #segmentation with vnet
    smooth=10e-06
    if params.softmax:
        smooth=0

    if params.model_type=='mnet':
        y_pred=mnet(images,labels.shape[-1],softmax=params.softmax,residual=params.residual)
    elif params.model_type=='mnet2':
        y_pred=mnet2(images,labels.shape[-1],softmax=params.softmax,residual=params.residual)
    elif params.model_type=='mnet3':
        y_pred=mnet3(images,labels.shape[-1],softmax=params.softmax,residual=params.residual)
    elif params.model_type=='unet':
        y_pred=unet(images,labels.shape[-1],base_num_filter=16,softmax=params.softmax,residual=params.residual)
    elif params.model_type=='vnet':
        y_pred=vnet(images,labels.shape[-1],softmax=params.softmax,residual=params.residual)
    elif params.model_type=='segnet':
        y_pred=segnet(images,labels.shape[-1],softmax=params.softmax,residual=params.residual)
    elif params.model_type=='vnetatrou':
        y_pred=vnetatrou(images,labels.shape[-1],softmax=params.softmax,residual=params.residual)
    else:
        print("nope nope nope nope")
        exit(0)
    y_true=labels
    if params.softmax:
        y_tr=y_true[:,:,:,:-1]
        y_pr=y_pred[:,:,:,:-1]
    else:
        y_tr=tf.round(y_true)
        y_pr=tf.round(y_pred)
    loss = superloss(y_true,y_pred)
    dice= dice_coeff(y_true,y_pred,smooth=smooth)
    intersection = tf.reduce_sum(y_true * y_pred)
    total_y_true=tf.reduce_sum(y_true)
    total_y_pred=tf.reduce_sum(y_pred)
    sem_union = tf.reduce_sum(y_true) + tf.reduce_sum(y_pred)
    union = sem_union - intersection

    dice_sep = dice_coeff_sep(y_true,y_pred,smooth=smooth)
    dice_sep_tot_true = tf.reduce_sum(y_true,axis=(0,1,2))
    dice_sep_tot_pred = tf.reduce_sum(y_pred,axis=(0,1,2))
    dice_sep_tot_inter = tf.reduce_sum(y_true * y_pred,axis=(0,1,2))
    jacard = jacard_index(y_true,y_pred,smooth=smooth)
    accuracy = 1- tf.reduce_mean(tf.abs(y_tr - y_pr))
    recall =  (tf.reduce_sum(y_pr * y_tr ) + smooth)  / ( tf.reduce_sum(y_tr) + smooth )
    spec = (tf.reduce_sum(y_pr*y_tr) + smooth ) / (tf.reduce_sum(y_pr) + smooth)

    tf.summary.scalar("loss",loss)
    tf.summary.scalar("dice_loss",dice)
    tf.summary.scalar("jacard_index",jacard)
    tf.summary.scalar("accuracy",accuracy)
    tf.summary.scalar("recall",recall)
    tf.summary.scalar("specificity",spec)
    tf.summary.scalar("dice 0",dice_sep[0])
    tf.summary.scalar("dice 1",dice_sep[1])
    tf.summary.scalar("dice 2",dice_sep[2])
    tf.summary.scalar("dice 3",dice_sep[3])

    merged = tf.summary.merge_all()

    zeroplease=tf.constant_initializer(0)

    estep=tf.get_variable("epoch_step",dtype=tf.float32,shape=[],initializer=zeroplease)
    estep_reset=tf.assign(estep,0)
    estep_inc=tf.assign(estep,estep+1)

    eloss=tf.get_variable("epoch_loss",dtype=tf.float32,shape=[],initializer=zeroplease)
    eloss_reset=tf.assign(eloss,0)
    eloss_update=tf.assign( eloss,(eloss*(estep-1)+loss)/estep)

    edice=tf.get_variable("epoch_dice",dtype=tf.float32,shape=[],initializer=zeroplease)
    edice_reset=tf.assign(edice,0)
    edice_update=tf.assign( edice,(edice*(estep-1)+dice)/estep)

    update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)

    seloss=tf.summary.scalar("avg_loss",eloss)
    sedice=tf.summary.scalar("avg_dice_loss",edice)

    update_e = tf.summary.merge((seloss,sedice))

    with tf.control_dependencies(update_ops):
        optimizer=tf.train.AdamOptimizer(learning_rate=learning_rate,beta1=params.momentum_decay)
        train=optimizer.minimize(loss,global_step=global_step)



    '''
    #classification of majority pixel
    y_pred=convnet(images,labels.shape[-1])
    print(labels.shape)
    y_true=tf.reduce_mean(labels,axis=[1,2])
    print(y_true.shape,y_pred.shape)
    
    loss = tf.losses.sigmoid_cross_entropy(y_true,y_pred)
    accuracy= 1- tf.reduce_mean(tf.abs(y_tr - y_pr))
    
    tf.summary.scalar("loss",loss) 
    tf.summary.scalar("accuracy",accuracy)
    tf.summary.scalar("recall",recall)
    tf.summary.scalar("specificity",spec)
    optimizer=tf.train.AdamOptimizer()
    train=optimizer.minimize(loss)
    print(accuracy)
    '''


summaries_dir=("tmp/model")


if params.do_train is True:
    with tf.Session() as sess:
        best=0
        train_writer = tf.summary.FileWriter(summaries_dir + '/train_{}'.format(model_name),
                                          sess.graph)
        test_writer = tf.summary.FileWriter(summaries_dir + '/test_{}'.format(model_name))
        train_it_handle=sess.run(train_iterator.string_handle())
        val_it_handle=sess.run(val_iterator.string_handle())
        feed_dict={x_train_placeholder: x_train_filenames,
               y_train_placeholder: y_train_filenames,
               num_x:len(x_train_filenames)}

        feed_dict_val={x_train_placeholder : x_val_filenames,
                       y_train_placeholder : y_val_filenames,
                       num_x:len(x_val_filenames)}
        saver = tf.train.Saver(max_to_keep=1000)
        try:
            saver.restore(sess, "tmp/{}.ckpt".format(model_name))
            if step_restore is None:
                saver.restore(sess, "tmp/{}.ckpt".format(model_name))
            else:
                saver.restore(sess, "tmp/{}.ckpt-{}".format(model_name,step_restore))
                step_restore=None
        except:
            sess.run(tf.global_variables_initializer())
        gs=sess.run(global_step)
        k=0
        tk=0
        n=gs//int(np.ceil(len(x_train_filenames)/batch_size))

        while gs+1<(epochs*int(np.ceil(len(x_train_filenames)/batch_size))):
            n+=1
            sess.run((train_iterator.initializer,estep_reset,eloss_reset,edice_reset),feed_dict=feed_dict)

            print("\nepoch {}/{}\n".format(n,epochs))
            start=time()
            
            tk+=k-tk
            veloss,vedice=(0,0)
            try:
                while True:
                    k+=1
                    summary,_,loss_value,accu,rec,speci,dice_value,gs,vestep,veloss,vedice,all_dice=sess.run((merged,train,loss,accuracy,recall,spec,dice,global_step,estep_inc,eloss_update,edice_update,dice_sep),
                                                             feed_dict={handle : train_it_handle,
                                                                        dropout_factor : 0.5,
                                                                        training : True})
                    train_writer.add_summary(summary,gs)
                    print('\r',"step {: =4}/{: =4} ({}),training loss/dice : {: =8.3} {: =8.3} ( {: =8.3} {: =8.3} {: =8.3} {: =8.3} ) , acc/rec/spe : {: =8.3} {: =8.3} {: =8.3}".format(k-tk,
                        int(len(x_train_filenames)/batch_size)+1,
                        gs,
                         loss_value,
                         dice_value,
                         all_dice[0],
                         all_dice[1],
                         all_dice[2],
                         all_dice[3],
                         accu,
                         rec,
                         speci),
                          end='')
                    with open('steps_{}'.format(model_name),'a') as f:

                        f.write('{},{},{},{},{},{},{},{},{},{}\n'.format(gs,
                         loss_value,
                         dice_value,
                         all_dice[0],
                         all_dice[1],
                         all_dice[2],
                         all_dice[3],
                         accu,
                         rec,
                         speci))

            except tf.errors.OutOfRangeError:
                pass

            print("\navg loss/dice : ",veloss,vedice)
            esummary=sess.run(update_e)
            train_writer.add_summary(esummary,gs)
        
            sess.run((val_iterator.initializer,estep_reset,eloss_reset,edice_reset),feed_dict=feed_dict_val)
            print("\n")              
            total_loss=0
            total_dice=0
            total_int=0
            total_fun=0
            total_true=0
            total_pred=0
            total_acc=0
            total_sep_true=np.zeros(labels.shape[-1],dtype=np.float)
            total_sep_pred=np.zeros(labels.shape[-1],dtype=np.float)
            total_sep_int=np.zeros(labels.shape[-1],dtype=np.float)
            v=0
            try:
                while True:
                    v+=1
                    summary,val_loss_value,accu,rec,speci,val_dice_value,vestep,veloss,vedice,tint,tfun,all_dice,ttrue,tpred,acc,sep_true,sep_pred,sep_int=sess.run((merged,loss,accuracy,recall,spec,dice,estep_inc,eloss_update,edice_update,intersection,sem_union,dice_sep,total_y_true,total_y_pred,accuracy,dice_sep_tot_true,dice_sep_tot_pred,dice_sep_tot_inter),feed_dict={handle : val_it_handle, dropout_factor : 1, training : False})
                    test_writer.add_summary(summary,gs)
                    total_loss+=val_loss_value
                    total_dice+=val_dice_value
                    total_int+=tint
                    total_fun+=tfun
                    total_true+=ttrue
                    total_pred+=tpred
                    total_acc+=acc
                    total_sep_true+=sep_true
                    total_sep_pred+=sep_pred
                    total_sep_int+=sep_int
                    print('\r',"step {: =5}/{: =5} ,training loss : {: =8.3}, dice : {: =8.3}".format(v,int(len(x_val_filenames)/batch_size)+1,val_loss_value,val_dice_value),end='') 
                    
            except tf.errors.OutOfRangeError:
                pass
            esummary=sess.run(update_e)
            test_writer.add_summary(esummary,gs)

            tot_sep=2.*total_sep_int/(total_sep_true+total_sep_pred)
            true_dice=2*total_int/total_fun
            with open('tests_{}'.format(model_name),'a') as f:

                f.write('{},{},{},{},{},{},{},{},{},{}\n'.format(gs,
                 total_loss/v,
                 true_dice,
                 tot_sep[0],
                 tot_sep[1],
                 tot_sep[2],
                 tot_sep[3],
                 total_acc/v,
                 total_int/total_true,
                 total_int/total_pred))


            print("\nepoch finished in {}\n".format(time()-start))
            print("\ntotal  loss : {} , total dice : {} , true dice : {}\n".format(total_loss/v,total_dice/v, true_dice))
            best=max(true_dice,best)
            if true_dice==best:
                save_path = saver.save(sess, "tmp/{}.ckpt".format(model_name))
                print("Best model saved in path: %s" % save_path)
            else:
                print("Best so far : %d" % best )
            save_path = saver.save(sess, "tmp/{}.ckpt".format(model_name),global_step=gs)
            print("Model saved in path: %s" % save_path)

if params.do_test is True:
    import cv2
    num_mask = len(y_test_filenames[0])
    final_fullsize_masks_pred=None

    for img_id in imgs_test:
        for img_index in [0,1]:
            print("processing {}_{}".format(img_id,img_index))
            prog=re.compile(".*/{}_{}_.*".format(img_id,img_index))
            x_val_filenames_single=np.array([s for s in filter(lambda x:prog.match(x) is not None,x_test_filenames)])
            y_val_filenames_single=np.array([[s for s in filter(lambda x:prog.match(x) is not None, y_test_filenames[:,i])] for i in range(num_mask)]).transpose()
            print(x_val_filenames_single.shape,y_val_filenames_single.shape)
            prog1=re.compile('{}_{}_0_.*'.format(img_id,img_index))
            prog2=re.compile('{}_{}_.*_0_.*'.format(img_id,img_index))
            col=len([s for s in filter(lambda x: prog1.match(x) is not None,test_filenames)])
            line=len([s for s in filter(lambda x: prog2.match(x) is not None,test_filenames)])
            print(col,line)
            if col==0 or line==0:
                break
            saver = tf.train.Saver(max_to_keep=1000)

            if final_fullsize_masks_pred is not None:
                del final_fullsize_masks_pred
                final_fullsize_masks_pred=None
            final_fullsize_masks_pred=np.zeros(((line+1)*img_shape[0],(col+1)*img_shape[1],num_mask))

            if params.offset :
                offsets=[]
                for not_i in np.linspace(-256,256,5,dtype=np.int):
                    for not_j in np.linspace(-256,256,5,dtype=np.int):
                        offsets.append((not_i,not_j))
            else:
                offsets=[(0,0)]

            for offset in offsets:

                if final_fullsize_masks_pred is not None:
                    del final_fullsize_masks_pred
                    final_fullsize_masks_pred=None
                final_fullsize_masks_pred=np.zeros(((line+1)*img_shape[0],(col+1)*img_shape[1],num_mask))

                test_cfg = {
                    'resize':[img_shape[0], img_shape[1]],
                    'offset_x' : offset[0],
                    'offset_y' : offset[1],
                    'background_class' : params.softmax
                }
                test_preprocessing_fn = functools.partial(_augment, **test_cfg)


                test_ds = get_baseline_dataset(x_train_placeholder,
                                              y_train_placeholder,
                                              num_x,
                                              test_preprocessing_fn,
                                              batch_size=batch_size,
                                              shuffle=False,
                                              threads=params.jobs,
                                              buff_size=params.buff)


                test_iterator = test_ds.make_initializable_iterator()

                with tf.Session() as sess:
                    try:
                        if step_restore is None:
                            saver.restore(sess, "tmp/{}.ckpt".format(model_name))
                        else:
                            saver.restore(sess, "tmp/{}.ckpt-{}".format(model_name,step_restore))
                    except:  
                        print("no model found")
                        sess.run(tf.global_variables_initializer())
                    test_it_handle=sess.run(test_iterator.string_handle())
                    feed_dict_val={x_train_placeholder : x_val_filenames_single,
                                   y_train_placeholder : y_val_filenames_single,
                                   num_x:len(x_val_filenames)}


                    n=0
                    
                    sess.run(test_iterator.initializer,feed_dict=feed_dict_val)
                    try:
                        while True:
                            t_img,t_true,t_pred=sess.run((images,y_true,y_pred),feed_dict={handle : test_it_handle,dropout_factor : 1,training : False})
                            for k in range(t_img.shape[0]):
                                y_fullsize=(n//col)*img_shape[0] + offset[1] + 256 + 128
                                x_fullsize=(n%col)*img_shape[1] + offset[0] + 256 + 128
                                final_fullsize_masks_pred[y_fullsize:y_fullsize+img_shape[0]-256,x_fullsize:x_fullsize+img_shape[1]-256,:]+=t_pred[k,128:-128,128:-128,:]
                                n+=1
                    except tf.errors.OutOfRangeError:
                        pass
                    except ValueError as e:
                        print(n,k,i)
                        print(e)
                        exit(0)

                print("saving fullsize mask ",end='')
                for i in range(num_mask):
                    print(i,end=' ')
                    if step_restore is None:
                        cv2.imwrite("fullmask_{}_{}_{}_{}_x{}_y{}.png".format(model_name,img_id,img_index,i,offset[0],offset[1]),final_fullsize_masks_pred[:,:,i]*255)
                    else: 
                        cv2.imwrite("fullmask_{}_{}_{}_{}_x{}_y{}_{}.png".format(model_name,img_id,img_index,i,offset[0],offset[1],step_restore),final_fullsize_masks_pred[:,:,i]*255)
            print("")

