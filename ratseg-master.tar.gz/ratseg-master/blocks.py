import tensorflow as tf
from layers import *

def conv_block(input,num_filters,name,f_w=3,f_h=3):
    with tf.variable_scope(name):
        encoder = conv(input,f_w,f_h,num_filters,"conv1")
        encoder = conv(encoder,f_w,f_h,num_filters,"conv2")
        encoder = conv(encoder,f_w,f_h,num_filters,"conv3")
        return encoder

def conv_block_n(input,num_filters,n,f_w=3,f_h=3,name="conv_block"):
    with tf.variable_scope(name):
        encoder = conv(input,f_w,f_h,num_filters,"conv0")
        for i in range(1,n):
            encoder = conv(encoder,f_w,f_h,num_filters,"conv{}".format(i))
        return encoder

def vgg_block(input,num_conv,num_filter,receptive_field,name):
    with tf.variable_scope(name):
        encoder = conv(input,receptive_field,receptive_field,num_filter,"conv0")
        for i in range(1,num_conv):
            encoder = conv(encoder,receptive_field,receptive_field,num_filter,"conv{}".format(i)) 
        #TODO put batch normalization here 
        encoder,pool_ind = tf.nn.max_pool_with_argmax(encoder,[1,2,2,1],[1,2,2,1],"VALID",Targmax=tf.int64,name="pool_with_argmax")
        return encoder,pool_ind
def encoder_block(input,num_filters,name,f_w,f_h,n):
    with tf.variable_scope(name):
        encoder = conv_block_n(input,num_filters,n,f_w,f_h,"conv_block")
        encoder_pool = pool(encoder)
        return encoder_pool,encoder

def encoder_block_argmax(input,num_filters,name,f_w,f_h,n):
    with tf.variable_scope(name):
        encoder = conv_block_n(input,num_filters,n,f_w,f_h,"conv_block")
        encoder_pool,encoder = tf.nn.max_pool_with_argmax(encoder,[1,2,2,1],[1,2,2,1],"VALID",Targmax=tf.int64,name="pool_with_argmax")
        return encoder_pool,encoder    

def encoder_res_block_argmax(input,num_filters,name,f_w,f_h,n):
    with tf.variable_scope(name):
        encoder = residual_block(input,num_filters,"conv_block",f_w,f_h,n)
        encoder_pool,encoder = tf.nn.max_pool_with_argmax(encoder,[1,2,2,1],[1,2,2,1],"VALID",Targmax=tf.int64,name="pool_with_argmax")
        return encoder_pool,encoder    


def encoder_res_block(input,num_filters,name,f_w,f_h,n):
    with tf.variable_scope(name):
        encoder = residual_block(input,num_filters,name,f_w,f_h,n)
        encoder_pool = pool(encoder)
        return encoder_pool,encoder

def residual_block(input,num_filters,name,f_w,f_h,n):
    with tf.variable_scope(name):
        shortcut=input
        encoder = conv_block_n(input,num_filters,n,f_w,f_h,"conv_block")
        if shortcut.shape[-1]!=encoder.shape[-1]:
            shortcut=conv(shortcut,1,1,num_filters,"conv_shortcut")
            shortcut=tf.layers.batch_normalization(shortcut)
        encoder = tf.add(shortcut,encoder)
        encoder = tf.nn.elu(encoder)
        return encoder

def decoder_block(input,concat,num_filters,name,f_w,f_h,n):
    with tf.variable_scope(name):
        #upped = deconv(input,num_filters,[dyn_input_shape[0],concat.shape[1],concat.shape[2],concat.shape[3]],name)
        upped = conv2d_transpose(name,input,num_filters,42,activation=tf.nn.elu)
        merged = tf.concat([upped,concat],axis=-1)
        decoder = conv_block_n(merged,num_filters,n,f_w,f_h,"conv_block")
        return decoder

def decoder_res_block(input,concat,num_filters,name,f_w,f_h,n):
    with tf.variable_scope(name):
        #upped = deconv(input,num_filters,[dyn_input_shape[0],concat.shape[1],concat.shape[2],concat.shape[3]],name)
        upped = conv2d_transpose(name,input,num_filters,42,activation=tf.nn.elu)
        merged = tf.concat([upped,concat],axis=-1)
        decoder = residual_block(merged,num_filters,"conv_block",f_w,f_h,n)
        return decoder

def leg(input,concat,num_filters=1,name="leg"):
        upped = tf.keras.layers.UpSampling2D()(input)
        merged = tf.concat([upped,concat],axis=-1)
        return merged

def unpool_block(input,ind,num_filters,name,f_w,f_h,n):
    with tf.variable_scope(name):
        merged = unpool_2d(input,ind)
        decoder = conv_block_n(merged,num_filters,n,f_w,f_h,"conv_block")
        return decoder
 
def unpool_res_block(input,ind,num_filters,name,f_w,f_h,n):
    with tf.variable_scope(name):
        merged = unpool_2d(input,ind)
        decoder = residual_block(merged,num_filters,"conv_block",f_w,f_h,n)
        return decoder
    
   
def dense_block(input,width,n,name):
    with tf.variable_scope(name):
        out = dense(input,width,"dense0")
        for i in range(1,n):
            out = dense(out,width,"dense{}".format(i))
        
        return out



