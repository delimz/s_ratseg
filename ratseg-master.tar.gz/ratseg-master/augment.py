import tensorflow as tf
import tensorflow.contrib as tfcontrib
import functools

def flip_img(horizontal_flip, tr_img, label_img):
    if horizontal_flip:
        flip_prob = tf.random_uniform([], 0.0, 1.0)
        tr_img, label_img = tf.cond(tf.less(flip_prob, 0.5),
                                lambda: (tf.image.flip_left_right(tr_img),
                                         tf.image.flip_left_right(label_img)),
                                lambda: (tr_img, label_img))
    return tr_img, label_img

def crop_strech_img(img,label_img, hor_crop_range, vert_crop_range,img_shape,offset_x,offset_y):
    if hor_crop_range!=0 and vert_crop_range!=0:
        cx=tf.random_uniform([],img_shape[0]/2,1024-img_shape[0]/2)
        cy=tf.random_uniform([],img_shape[1]/2,1024-img_shape[1]/2)
    else:
        cx=512+offset_x
        cy=512+offset_y
    y1=cy-img_shape[0]/2
    y2=cy+img_shape[0]/2
    x1=cx-img_shape[1]/2
    x2=cx+img_shape[1]/2
    dx=tf.random_uniform([],0.0,hor_crop_range/2)
    dy=tf.random_uniform([],0.0,vert_crop_range/2)
    bbox=tf.add(tf.stack([y1, x1, y2, x2])/int(1024),[-dy,-dx,dy,dx])

    bbox = tf.reshape(tf.cast(bbox,tf.float32),[1,4])
    #bbox4 = tf.concat([bbox,bbox,bbox,bbox],axis=0)
    box_ind=[0]
    #box_ind4=tf.range(4)
   
    crop_size=[img_shape[0],img_shape[1]]
    img = tf.image.crop_and_resize([img],bbox,box_ind,crop_size)[0]
    label_img = tf.image.crop_and_resize([label_img], bbox,box_ind,crop_size )[0]
    return img,label_img

def rotate_img(img,label_img):
    angle = tf.random_uniform([],-30,30)
    img = tfcontrib.image.rotate(img,angle*(3.14159265358979323846/180))
    label_img = tfcontrib.image.rotate(label_img,angle)
    return img, label_img

def _augment(img,
             label_img,
             resize=None,  # Resize the image to some size e.g. [256, 256]
             scale=1,  # Scale image e.g. 1 / 255.
             offset_x=0,
             offset_y=0,
             hue_delta=0,  # Adjust the hue of an RGB image by random factor
             saturation_delta=0,
             brightness_delta=0,
             contrast_delta=0,
             horizontal_flip=False,  # Random left right flip,
             rotate=False,
             hor_crop_range=0,
             vert_crop_range=0,
             width_shift_range=0,  # Randomly translate the image horizontally
             height_shift_range=0,
             img_shape=(512,512,3),
             background_class=False):  # Randomly translate the image vertically 
    
    
    label_img = tf.to_float(label_img) * scale
    img = tf.to_float(img) * scale 
    if rotate:
        img, label_img = rotate_img(img,label_img)
    img, label_img = crop_strech_img(img,label_img,hor_crop_range,vert_crop_range,img_shape,offset_x,offset_y)

    if hue_delta:
        img = tf.image.random_hue(img, hue_delta)
    if saturation_delta:
        img = tf.image.random_saturation(img, 1- saturation_delta,1+saturation_delta)
    if brightness_delta:
        img = tf.image.random_brightness(img,brightness_delta)
    if contrast_delta:
        img = tf.image.random_contrast(img, 1 - contrast_delta, 1+ contrast_delta)


    img, label_img = flip_img(horizontal_flip, img, label_img)
    #img, label_img = shift_img(img, label_img, width_shift_range, height_shift_range)
    if background_class:
        neg=tf.maximum(tf.ones_like(label_img[:,:,0:1])-tf.reduce_sum(label_img,axis=2,keep_dims=True),0)
        print("neg",neg.shape)
        label_img = tf.math.softmax(tf.concat([label_img,neg],axis=-1))
        print("lab",label_img.shape)

    return img, label_img


