import tensorflow as tf
import functools

def sortkey(x):
    sp=x.split('_')
    return int(sp[2])*100000+int(sp[3])


def _process_pathnames(fname, label_path):
    ''' fetch the image data

    fname : image filenames
    label_path : list of image labels
    '''
    # We map this function onto each pathname pair  
    img_str = tf.read_file(fname)
    img = tf.truediv(tf.to_float(tf.image.decode_jpeg(img_str, channels=3)),255.0)
    label_img_str = tf.map_fn(tf.read_file,label_path)
    decoder = functools.partial(tf.image.decode_jpeg)
    label_img = tf.map_fn(decoder,label_img_str,dtype=tf.uint8)
    # The label image should only have values of 1 or 0, indicating pixel wise
    # object (car) or not (background). We take the first channel only.
    label_img = tf.image.convert_image_dtype(label_img[:,:,:,0],dtype=tf.float32)# the conversion takes car of mapping values 0-255 to 0-1
    label_img = tf.transpose(label_img,perm=[1,2,0])
    return img, label_img


def get_baseline_dataset(filenames, 
                         labels,
                         num_x,
                         preproc_fn=lambda x : x,
                         threads=16, 
                         batch_size=5,
                         shuffle=True,
                         buff_size=20,
                         cache=False):
    # Create a dataset from the filenames and labels
    dataset = tf.data.Dataset.from_tensor_slices((filenames, labels))
    
    if shuffle:
        dataset = dataset.shuffle(num_x)
    
    dataset = dataset.map(_process_pathnames)
    if cache == True:
        dataset = dataset.cache()
    # Map our preprocessing function to every element in our dataset, taking
    # advantage of multithreading
    dataset =dataset.map(preproc_fn, num_parallel_calls=threads)
                     
    # It's necessary to repeat our data for all epochs 
    dataset = dataset.batch(batch_size)
    
    return dataset.prefetch(buff_size)


