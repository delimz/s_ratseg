import os
from cytomine import Cytomine
from cytomine.models.image import ImageInstanceCollection

def get_image_map(params):
    with Cytomine(host=params.host, public_key=params.public_key, private_key=params.private_key) as cytomine:
        image_instances = ImageInstanceCollection().fetch_with_filter("project", params.id_project)
        res=dict()
        for image in image_instances:
            filename=image.filename.split("/")[2]
            res[image.id]=filename
            if params.download_path:
                # To download the original files that have been uploaded to Cytomine
                path=os.path.join(params.download_path, filename)
                print(path)
                if not os.path.exists(path):
                    image.download(path)
        return res

if __name__ == "__main__":
    
    from argparse import ArgumentParser
    import sys

    parser = ArgumentParser(prog="ratseg_get_data")
    parser.add_argument('--cytomine_host', dest='host',
                        default='https://demo.cytomine.coop', help="The Cytomine host")
    parser.add_argument('--cytomine_public_key', dest='public_key',
                        default='5870ca8a-d1a6-4f8c-b51c-6cdb871cba5b',
                        help="The Cytomine public key")
    parser.add_argument('--cytomine_private_key', dest='private_key',
                        help="The Cytomine private key",
                        default='7d890db3-2537-4f7a-b313-2c36b208c22f')
    parser.add_argument('--cytomine_id_project', dest='id_project',
                        help="The project from which we want the images",
                        default=1012227)
    parser.add_argument('--download_path',
                        help="Where to store images",
                        default='/home/donovan/Downloads/')

    params=parser.parse_args(sys.argv[1:])

    for k in get_image_map(params).keys():
        print(k,end=" ")
    print("")

