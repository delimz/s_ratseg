import tensorflow as tf
from tensorflow.python.keras import backend as K  

import numpy as np

def dice_coeff(y_true, y_pred,smooth=1, channel=None):
    intersection = tf.reduce_sum(y_true * y_pred)
    score = (2. * intersection + smooth ) / (K.sum(y_true) + K.sum(y_pred) + smooth)
    return tf.reduce_mean(score)

def dice_coeff_sep(y_true, y_pred,smooth=1,thresh=0.5):
    return tf.stack((
            (2. * tf.reduce_sum(y_true[:,:,:,0] * y_pred[:,:,:,0]) + smooth ) / (tf.reduce_sum(y_true[:,:,:,0]) + tf.reduce_sum(y_pred[:,:,:,0]) + smooth),
            (2. * tf.reduce_sum(y_true[:,:,:,1] * y_pred[:,:,:,1]) + smooth ) / (tf.reduce_sum(y_true[:,:,:,1]) + tf.reduce_sum(y_pred[:,:,:,1]) + smooth),
            (2. * tf.reduce_sum(y_true[:,:,:,2] * y_pred[:,:,:,2]) + smooth ) / (tf.reduce_sum(y_true[:,:,:,2]) + tf.reduce_sum(y_pred[:,:,:,2]) + smooth),
            (2. * tf.reduce_sum(y_true[:,:,:,3] * y_pred[:,:,:,3]) + smooth ) / (tf.reduce_sum(y_true[:,:,:,3]) + tf.reduce_sum(y_pred[:,:,:,3]) + smooth)))
    


def weighted_dice_coeff(y_true,y_pred,smooth=1,weights=np.array([1,1,1,1])):
    intersection = y_true * y_pred

    score = ( tf.reduce_sum(2. * intersection * weights) + smooth ) / ( tf.reduce_sum( ( y_true + y_pred ) * weights ) + smooth )
    #score = ( 2. * tf.reduce_sum( intersection ) + smooth ) / ( tf.reduce_sum( ( y_true + y_pred ) ) + smooth )

    return tf.reduce_mean(score)

def jacard_index(y_true,y_pred,smooth=1):
    '''intersection over union'''
    y_true_f = K.flatten(y_true)
    y_pred_f = K.flatten(y_pred)
    
    intersection = K.sum(y_true_f * y_pred_f)
    union = K.sum(y_true_f + y_pred_f - y_true_f * y_pred_f )
    index = K.mean(( intersection  + smooth) / (union + smooth))
    return index

def dice_loss(y_true, y_pred):
    loss = 1 - dice_coeff(y_true, y_pred)
    return loss

def bce_dice_loss(y_true, y_pred):
    loss = tf.losses.sigmoid_cross_entropy(y_true, y_pred) + dice_loss(y_true, y_pred)
    return loss

def bce_log_dice_loss(y_true,y_pred):
    loss = tf.losses.sigmoid_cross_entropy(y_true,y_pred) - tf.log(dice_coeff(y_true,y_pred)) 
    return loss

def focal_loss(y_true,y_pred,gamma=4,beta=0,weights=[1,1,1,1]):
    pt= tf.math.sigmoid( gamma * ((y_true - 0.5)*2) * ((y_pred - 0.5)*2) + beta)
    loss = -  tf.log(pt) / gamma
    return tf.reduce_mean(loss * weights)

def superloss(y_true,y_pred,gamma=1):
    weights = tf.reduce_sum(y_true,axis=(0,1,2)) + 1e-6
    weights = weights / (tf.reduce_sum(weights) + 1e-6)
    print("w", weights)
    return tf.pow(focal_loss(y_true,y_pred,4,0,weights=weights),gamma) + tf.pow( - tf.log(weighted_dice_coeff(y_true,y_pred,weights=weights)),gamma)
