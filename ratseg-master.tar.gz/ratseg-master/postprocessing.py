import os
import cv2
import matplotlib.pyplot as plt
import numpy as np
from time import time

from shapely.wkt import loads
from shapely.affinity import translate

import tensorflow as tf
tf.enable_eager_execution()

from cytomine import Cytomine
from cytomine.models import AnnotationCollection,Annotation
from cytomine.models.image import ImageInstanceCollection

from argparse import ArgumentParser
import sys

parser = ArgumentParser(prog="ratseg_postproc")
parser.add_argument('--cytomine_host', dest='host',
                    default='https://demo.cytomine.coop', help="The Cytomine host")
parser.add_argument('--cytomine_public_key', dest='public_key',
                    default='5870ca8a-d1a6-4f8c-b51c-6cdb871cba5b',
                    help="The Cytomine public key")
parser.add_argument('--cytomine_private_key', dest='private_key',
                    help="The Cytomine private key",
                    default='7d890db3-2537-4f7a-b313-2c36b208c22f')
parser.add_argument('--cytomine_id_project', dest='id_project',
                    help="The project from which we want the images",
                    default=1012227)
parser.add_argument('--slice_term',type=int,
                    help="id of the ROI delimiting annotation",
                    default=2469614)
parser.add_argument('--patch-size',default=1024)

parser.add_argument('--model','-m',help="name of the model to evaluate")

parser.add_argument('--imgs-test',type=int,nargs='+',default=[2319579,  2319561, 2319541,2319573])#2319573,
parser.add_argument('--terms',type=int,nargs='+',default=[1012286,1012259,1012265,1012280]) #gm l b d #1012294 = gc
parser.add_argument('--threshold',type=float,default=0.5)
parser.add_argument('--no',type=int,default=4,help="number of errosion and dilation passes for openning and closing")

params=parser.parse_args(sys.argv[1:])

model=params.model
threshold=params.threshold
test_imgs=params.imgs_test
print("imgs",test_imgs)

host=params.host
public_key=params.public_key
private_key=params.private_key
id_project=params.id_project
slice_term=params.slice_term
terms=params.terms
no=params.no

def getpolygon(img,offset=(0,0)):
    res=cv2.findContours(img,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    poly="MULTIPOLYGON ({})"
    polys=[]
    if len(res[0])>0:
        for p in res[0]:
            if len(p)>4:
                subpoly="(({}))"
                try:
                    ps=["%d %d" % (x[0][0]+offset[0],x[0][1]+offset[1]) for x in p]
                except Exception as e:
                    print(res)
                    print(p)
                    print(e)
                    exit(1)
                ps.append(ps[0])
                points=','.join(ps)
                polys.append(subpoly.format(points))
    if len(polys)==0:
        polys=["EMPTY"]
    final=poly.format(",".join(polys))
    try:
        res=loads(final)
    except Exception as e:
        print(final)
        print('ERROR : ',e)
        exit(0)
        res=loads(poly.format("EMPTY"))

    return res

def one_of_us(s):
    for img in test_imgs:
        if s.startswith('fullmask_%s_%d' % (model,img)):
            return True
    return False

shapes={}
fm=sorted([f for f in filter(one_of_us ,os.listdir('.'))])
print(fm)

for f in fm:
    img=cv2.imread("./%s" % f,cv2.IMREAD_GRAYSCALE)
    imshape=img.shape
    ks=12
    start=time()
    kernel1=np.array(cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (ks,ks))/255.0,dtype=np.float16)
    kernel1=kernel1.reshape((ks,ks,1))
    kernel2=np.array(np.matmul(cv2.getGaussianKernel(ks,-1),cv2.getGaussianKernel(ks,-1).transpose()),dtype=np.float16).reshape((ks,ks,1))

    img=tf.image.convert_image_dtype(img,dtype=tf.float16)
    img=tf.reshape(img,(1,imshape[0],imshape[1],1))
    for i in range(no):
        img=tf.nn.erosion2d(img,kernel2,[1,1,1,1],[1,1,1,1],'SAME')
    for i in range(no*2):
        img=tf.nn.dilation2d(img,kernel2,[1,1,1,1],[1,1,1,1],'SAME')
    for i in range(no):
        img=tf.nn.erosion2d(img,kernel2,[1,1,1,1],[1,1,1,1],'SAME')
    img=img[0,:,:,0]
    for t in np.linspace(0.1,0.9,9):
        cond=tf.less(img,tf.constant(t,shape=imshape,dtype=tf.float16))
        imgt=tf.where(cond,tf.zeros(tf.shape(img),dtype=tf.float16),img)
        imgt=tf.image.convert_image_dtype(imgt,dtype=tf.uint8)
        imgt=cv2.flip(imgt.numpy(),0)
        shapes[(f,t)]=getpolygon(imgt)
        print(time() - start)
        print(f,t,"valid?",shapes[(f,t)].is_valid)
        

ploys={}
for f in shapes.keys():
    if shapes[f].is_valid:
        print(0)
        ploys[f]=shapes[f]
        continue
    else:
        i=0
        while i<1000:
            if shapes[f].simplify(i).is_valid:
                break
            i=i+1
        print(i)
        ploys[f]=shapes[f].simplify(i)

print(ploys)
#populate res with the annotations
with Cytomine(host=host, public_key=public_key, private_key=private_key) as cytomine:
    res={}
    annotations = AnnotationCollection()
    annotations.project = id_project
    annotations.showWKT = True
    annotations.showMeta = True
    annotations.showGIS = True
    annotations.showTerm = True
    annotations.showImage = True
    annotations.fetch()
    print(annotations)
    for annotation in annotations:
        '''
        print("ID: {} | Img: {} | Pjct: {} | Term: {} ".format(
            annotation.id,
            annotation.image,
            annotation.project,
            annotation.term
        ))
        '''
        if len(annotation.term)==1:
            if (annotation.term[0],annotation.image) not in res.keys():
                res[(annotation.term[0],annotation.image)]=[]
            res[(annotation.term[0],annotation.image)].append(loads(annotation.location))
            last=res[(annotation.term[0],annotation.image)][-1]
tshapes={}
def get_tshapes(f):
    if f in tshapes.keys():
        return tshapes[f]
    else:
        img=cv2.imread("./%s" % f,cv2.IMREAD_GRAYSCALE)
        img=cv2.flip(img,0)
        try:
            tshapes[f]=getpolygon(img)
            print(f,"valid?",tshapes[f].is_valid)
        except Exception as e:
            print(f,"fucked!",e)
            return None

        if tshapes[f].is_valid:
            print(0)
            tshapes[f]=tshapes[f]
        else:
            i=0
            while i<20:
                if tshapes[f].simplify(i).is_valid:
                    break
                i=i+1
            print('simplified',i)
            tshapes[f]=tshapes[f].simplify(i)
        return tshapes[f]

results_t={}
for thresh in np.linspace(0.1,0.9,9):
    results=[]
    for test_img in test_imgs:
        for index in range(2):
            results.append([])
            try:
                try:
                    ploy=[ploys[('fullmask_%s_%d_%d_%d.png' % (model,test_img,index,t),thresh)] for t in range(len(terms))]
                    print(ploy)
                    x,y,w,h=res[(slice_term,test_img)][index].bounds
                    print(x,y,w,h)
                except Exception as e:
                    print('no fullmask_%s_%d_%d_?.png' % (model,test_img,index),e)
                    exit(0)

                '''
                try:
                    l=ploy[1]
                    b=ploy[2].difference(l)
                    d=ploy[3].difference(b.union(l))
                    gm=ploy[0].difference(l.union(b).union(d))
                except Exception as e:
                    print('error %d' % (test_img),e)
                '''
                l=ploy[1]
                b=ploy[2]
                d=ploy[3]
                gm=ploy[0]

                offy=640
                offx=0
                tgm=translate(get_tshapes('%d_%d_%d.png' % (test_img,index,terms[0])),yoff=offy,xoff=offx)
                tl=translate(get_tshapes('%d_%d_%d.png' % (test_img,index,terms[1])),yoff=offy,xoff=offx)
                tb=translate(get_tshapes('%d_%d_%d.png' % (test_img,index,terms[2])),yoff=offy,xoff=offx)
                td=translate(get_tshapes('%d_%d_%d.png' % (test_img,index,terms[3])),yoff=offy,xoff=offx)
                
                results[-1].append(l.intersection(tl).area/l.union(tl).area)
                results[-1].append(b.intersection(tb).area/b.union(tb).area)
                results[-1].append(d.intersection(td).area/d.union(td).area)
                results[-1].append(gm.intersection(tgm).area/gm.union(tgm).area)

                print(l.intersection(tl).area/l.union(tl).area)
                print(b.intersection(tb).area/b.union(tb).area)
                print(d.intersection(td).area/d.union(td).area)
                print(gm.intersection(tgm).area/gm.union(tgm).area)
            except Exception as e:
                print('bad geometry or other error for',test_img,index,'at',thresh)
                print(*[x.is_valid for x in [l,b,d,gm,tl,tb,td,tgm]])
                print(e)
                results[-1]=[0,0,0,0]

    results_t[thresh]=results

threshs=np.linspace(0.1,0.9,9)
res=np.array([results_t[thresh]  for thresh in np.linspace(0.1,0.9,9)])
maxes=np.argmax(np.average(res,axis=1),axis=0)
print(results_t)
print(maxes)
maxes=[threshs[maxes[n]] for n in [3,0,1,2]]
results=[]
for test_img in test_imgs:
    for index in range(2):
        results.append([])
        ploy=[0]*len(maxes)
        for n in range(len(maxes)):
            ploy[n]=ploys[('fullmask_%s_%d_%d_%d.png' % (model,test_img,index,n),maxes[n])]


        offy=640
        offx=0
        tgm=translate(get_tshapes('%d_%d_%d.png' % (test_img,index,terms[0])),yoff=offy,xoff=offx)
        tl=translate(get_tshapes('%d_%d_%d.png' % (test_img,index,terms[1])),yoff=offy,xoff=offx)
        tb=translate(get_tshapes('%d_%d_%d.png' % (test_img,index,terms[2])),yoff=offy,xoff=offx)
        td=translate(get_tshapes('%d_%d_%d.png' % (test_img,index,terms[3])),yoff=offy,xoff=offx)
        
        results[-1].append(l.intersection(tl).area/l.union(tl).area)
        results[-1].append(b.intersection(tb).area/b.union(tb).area)
        results[-1].append(d.intersection(td).area/d.union(td).area)
        results[-1].append(gm.intersection(tgm).area/gm.union(tgm).area)
        with open("shapes",'a') as f:
            shaps=(gm,l,b,d)
            for n in range(len(shaps)):
                f.write("shape_%s_%d_%d_%d=loads('%s')\n" % (model,test_img,index,n,shaps[n].wkt))
        try:
            l=ploy[1]
            b=ploy[2].difference(l)
            d=ploy[3].difference(b.union(l))
            gm=ploy[0].difference(l.union(b).union(d))

            offy=640
            offx=0
            tgm=translate(get_tshapes('%d_%d_%d.png' % (test_img,index,terms[0])),yoff=offy,xoff=offx)
            tl=translate(get_tshapes('%d_%d_%d.png' % (test_img,index,terms[1])),yoff=offy,xoff=offx)
            tb=translate(get_tshapes('%d_%d_%d.png' % (test_img,index,terms[2])),yoff=offy,xoff=offx)
            td=translate(get_tshapes('%d_%d_%d.png' % (test_img,index,terms[3])),yoff=offy,xoff=offx)
            
            results[-1].append(l.intersection(tl).area/l.union(tl).area)
            results[-1].append(b.intersection(tb).area/b.union(tb).area)
            results[-1].append(d.intersection(td).area/d.union(td).area)
            results[-1].append(gm.intersection(tgm).area/gm.union(tgm).area)
        except Exception as e:
            print("final?",test_img, index)
            print(e)


print(results)
with open("postres",'a') as f:
    f.write(model)
    f.write("=")
    f.write(str(results_t))
    f.write('\n')
    f.write(model)
    f.write('_max')
    f.write("=")
    f.write(str(results))
    f.write('\n')
