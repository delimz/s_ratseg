import tensorflow as tf

training = tf.placeholder(tf.bool,None,"is_training")

def conv(input,filter_height,filter_width,num_filters,name,dilations=[1,1,1,1],activation=tf.nn.elu):
    with tf.variable_scope(name):
        filters=tf.get_variable("filter",
                            [filter_height,filter_width,input.shape[-1],num_filters],
                           initializer=tf.initializers.truncated_normal(stddev=.1))
        layer=tf.nn.conv2d(input,filters,[1,1,1,1],"SAME",data_format="NHWC",dilations=dilations)

        bias = tf.get_variable("bias",[num_filters],dtype=tf.float32,
                              initializer=tf.constant_initializer(0.0))
        layer = tf.nn.bias_add(layer,bias)
        layer = tf.layers.batch_normalization(layer,training=training)
        activated = activation(layer)

        return activated

def conv_softmax(input,filter_height,filter_width,num_filters,name):
    with tf.variable_scope(name):
        filters=tf.get_variable("filter",
                            [filter_height,filter_width,input.shape[-1],num_filters],
                           initializer=tf.initializers.truncated_normal(stddev=.1))

        layer=tf.nn.conv2d(input,filters,[1,1,1,1],"SAME")
        bias = tf.get_variable("bias",[num_filters],dtype=tf.float32,
                              initializer=tf.constant_initializer(0.0))
        layer = tf.nn.bias_add(layer,bias)
        
        activated = tf.nn.softmax(layer)

        return activated


def conv_sig(input,filter_height,filter_width,num_filters,name):
    with tf.variable_scope(name):
        filters=tf.get_variable("filter",
                            [filter_height,filter_width,input.shape[-1],num_filters],
                           initializer=tf.initializers.truncated_normal(stddev=.1))

        layer=tf.nn.conv2d(input,filters,[1,1,1,1],"SAME")
        bias = tf.get_variable("bias",[num_filters],dtype=tf.float32,
                              initializer=tf.constant_initializer(0.0))
        layer = tf.nn.bias_add(layer,bias)
        
        activated = tf.nn.sigmoid(layer)

        return activated

def pool(input):
    layer=tf.nn.max_pool(input,[1,2,2,1],[1,2,2,1],"VALID")
    return layer

def unpool_2d(pool, 
           ind, 
           stride=[1, 2, 2, 1], 
           scope='unpool_2d'):

    #https://github.com/tensorflow/tensorflow/pull/16885
    """Adds a 2D unpooling op.
    
    https://arxiv.org/abs/1505.04366
    Unpooling layer after max_pool_with_argmax.
         Args:
             pool:        max pooled output tensor
             ind:         argmax indices
             stride:      stride is the same as for the pool
         Return:
             unpool:    unpooling tensor
    """
    with tf.variable_scope(scope):
        input_shape = tf.shape(pool)
        output_shape = [input_shape[0], input_shape[1] * stride[1], input_shape[2] * stride[2], input_shape[3]]

        flat_input_size = tf.reduce_prod(input_shape)
        flat_output_shape = [output_shape[0], output_shape[1] * output_shape[2] * output_shape[3]]

        pool_ = tf.reshape(pool, [flat_input_size])
        batch_range = tf.reshape(tf.range(tf.cast(output_shape[0], tf.int64), dtype=ind.dtype),
                shape=[input_shape[0], 1, 1, 1])
        b = tf.ones_like(ind) * batch_range
        b1 = tf.reshape(b, [flat_input_size, 1])
        ind_ = tf.reshape(ind, [flat_input_size, 1])
        ind_ = tf.concat([b1, ind_], 1)

        ret = tf.scatter_nd(ind_, pool_, shape=tf.cast(flat_output_shape, tf.int64))
        ret = tf.reshape(ret, output_shape)

        set_input_shape = pool.get_shape()
        set_output_shape = [set_input_shape[0], set_input_shape[1] * stride[1], set_input_shape[2] * stride[2], set_input_shape[3]]
        ret.set_shape(set_output_shape)
        return ret

def down_conv(input,name="down_conv"):
    with tf.variable_scope(name):
        filters=tf.get_variable("filter",
                                [2,2,input.shape[-1],input.shape[-1]],
                                initializer=tf.initializers.truncated_normal(stddev=.1))
        layer=tf.nn.conv2d(input,filters,[1,2,2,1],"VALID")
        bias = tf.get_variable("bias",[input.shape[-1]],dtype=tf.float32,
                              initializer=tf.constant_initializer(0.0))
        layer = tf.nn.bias_add(layer,bias)
        layer = tf.layers.batch_normalization(layer,training=training)
        activated=tf.nn.elu(layer)
        return activated

def deconv(input,num_filters,out_shape,name):
    with tf.variable_scope(name):
        filters=tf.get_variable("filter",[2,2,num_filters,input.shape[-1]],
                           initializer=tf.initializers.truncated_normal(stddev=.1))
        layer=tf.nn.conv2d_transpose(input,filters,out_shape,[1,2,2,1])

        bias = tf.get_variable("bias",[num_filters],dtype=tf.float32,
                              initializer=tf.constant_initializer(0.0))
        layer= tf.nn.bias_add(layer,bias)
        layer = tf.layers.batch_normalization(layer,training=training)
        activ = tf.nn.elu(layer)
        return activ

def conv2d_transpose(name_or_scope,
                     x, n_filters,
                     batch_size,
                     k_h=2, k_w=2,
                     stride_h=2,stride_w=2,
                     stddev=0.1, bias=0.0,
                     activation=lambda x: x,
                     padding='SAME',):
    #implementation found here: https://github.com/tensorflow/tensorflow/issues/833
    #because of issue with shape correspondance
    with tf.variable_scope(name_or_scope):
        static_input_shape = x.get_shape().as_list()
        dyn_input_shape = tf.shape(x)

        # extract batch-size like as a symbolic tensor to allow variable size
        batch_size = dyn_input_shape[0]

        w = tf.get_variable(
            'W', [k_h, k_w, n_filters, static_input_shape[-1]],
            initializer=tf.truncated_normal_initializer(stddev=stddev))

        assert padding in {'SAME', 'VALID'}
        if (padding is 'SAME'):
            out_h = dyn_input_shape[1] * stride_h
            out_w = dyn_input_shape[2] * stride_w
        elif (padding is 'VALID'):
            out_h = (dyn_input_shape[1] - 1) * stride_h + k_h
            out_w = (dyn_input_shape[2] - 1) * stride_w + k_w

        out_shape = tf.stack([batch_size, out_h, out_w, n_filters])

        convt = tf.nn.conv2d_transpose(
            x, w, output_shape=out_shape,
            strides=[1, stride_h, stride_w, 1], padding=padding)
        b = tf.get_variable(
            'b', [n_filters],
            initializer=tf.constant_initializer(bias))
        convt += b
    return activation(convt)


def dense(input,width,name,activation=tf.nn.elu):
    with tf.variable_scope(name):
        
        w = tf.get_variable(
            'W', [  input.shape[-1],width ],
            initializer=tf.truncated_normal_initializer(stddev=.02))
        
        b = tf.get_variable(
            'b', [width],
            initializer=tf.constant_initializer(.0))
        out=activation( tf.matmul(input,w) + b)
        return tf.nn.dropout(out,dropout_factor)
 
