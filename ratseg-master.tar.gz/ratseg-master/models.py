import tensorflow as tf
from blocks import *
from layers import *

def vnet(input,num_out,name="vnet",softmax=False,residual=True):
    if residual:
        encode=encoder_res_block
        decode=decoder_res_block
    else:
        encode=encoder_block
        decode=decoder_block

    with tf.variable_scope(name,reuse=tf.AUTO_REUSE):
        encoder1, encoded1 = encode(input,16,"encoder1",7,7,3)
        encoder2, encoded2 = encode(encoder1,32,"encoder2",7,7,3)
        encoder3, encoded3 = encode(encoder2,64,"encoder3",5,5,3)
        encoder4, encoded4 = encode(encoder3,128,"encoder4",5,5,3)
        encoder5, encoded5 = encode(encoder4,256,"encoder5",3,3,3)
        center = conv_block(encoder5,512,"center")
        decoder5 = decode(center,encoded5,256,"decoder5",3,3,3)
        decoder4 = decode(decoder5,encoded4,128,"decoder4",5,5,3)
        decoder3 = decode(decoder4,encoded3,64,"decoder3",5,5,3)
        decoder2 = decode(decoder3,encoded2,32,"decoder2",7,7,3)
        decoder1 = decode(decoder2,encoded1,16,"decoder1",7,7,3)
        output = conv_sig(decoder1,1,1,num_out,"output")
        return output

def vnetatrou(input,num_out,name="vnet",softmax=False,residual=True):
    if residual:
        encode=encoder_res_block
        decode=decoder_res_block
    else:
        encode=encoder_block
        decode=decoder_block

    with tf.variable_scope(name,reuse=tf.AUTO_REUSE):
        encoder1, encoded1 = encode(input,16,"encoder1",3,3,3,dilations=[1,3,3,1])
        encoder2, encoded2 = encode(encoder1,32,"encoder2",3,3,3,dilations=[1,3,3,1])
        encoder3, encoded3 = encode(encoder2,64,"encoder3",3,3,3,dilations=[1,2,2,1])
        encoder4, encoded4 = encode(encoder3,128,"encoder4",3,3,3,dilations=[1,2,2,1])
        encoder5, encoded5 = encode(encoder4,256,"encoder5",3,3,3)
        center = conv_block(encoder5,512,"center")
        decoder5 = decode(center,encoded5,256,"decoder5",3,3,3)
        decoder4 = decode(decoder5,encoded4,128,"decoder4",5,5,3)
        decoder3 = decode(decoder4,encoded3,64,"decoder3",5,5,3)
        decoder2 = decode(decoder3,encoded2,32,"decoder2",7,7,3)
        decoder1 = decode(decoder2,encoded1,16,"decoder1",7,7,3)
        output = conv_sig(decoder1,1,1,num_out,"output")
        return output


def mnet(input,num_out,name="mnet",softmax=False,residual=True):
    if residual:
        encode=encoder_res_block
        decode=decoder_res_block
    else:
        encode=encoder_block
        decode=decoder_block

    with tf.variable_scope(name,reuse=tf.AUTO_REUSE):
        encoder1, encoded1 = encode(input,16,"encoder1",3,3,3)
        encoder2, encoded2 = encode(encoder1,32,"encoder2",3,3,3)
        encoder3, encoded3 = encode(encoder2,64,"encoder3",3,3,3)
        encoder4, encoded4 = encode(encoder3,128,"encoder4",3,3,3)
        encoder5, encoded5 = encode(encoder4,256,"encoder5",3,3,3)
        center = conv_block(encoder5,512,"center")
        decoder5 = decode(center,encoded5,256,"decoder5",3,3,3)
        decoder4 = decode(decoder5,encoded4,128,"decoder4",3,3,3)
        decoder3 = decode(decoder4,encoded3,64,"decoder3",3,3,3)
        decoder2 = decode(decoder3,encoded2,32,"decoder2",3,3,3)
        decoder1 = decode(decoder2,encoded1,16,"decoder1",3,3,3)
        
        with tf.variable_scope("legs",reuse=tf.AUTO_REUSE):
            leg4 = leg(decoder5,decoder4,name="leg4") 
            leg3 = leg(leg4,decoder3,name="leg3") 
            leg2 = leg(leg3,decoder2,name="leg2") 
            leg1 = leg(leg2,decoder1,name="leg1") 

        if softmax:
            output = conv_softmax(leg1,1,1,num_out,"output")
        else:
            output = conv_sig(leg1,1,1,num_out,"output")
        return output

def mnet2(input,num_out,name="mnet2",softmax=False,residual=True):
    if residual:
        encode=encoder_res_block
        decode=decoder_res_block
    else:
        encode=encoder_block
        decode=decoder_block

    with tf.variable_scope(name,reuse=tf.AUTO_REUSE):
        encoder1, encoded1 = encode(input,16,"encoder1",7,7,3)
        encoder2, encoded2 = encode(encoder1,32,"encoder2",7,7,3)
        encoder3, encoded3 = encode(encoder2,64,"encoder3",5,5,3)
        encoder4, encoded4 = encode(encoder3,128,"encoder4",5,5,3)
        encoder5, encoded5 = encode(encoder4,256,"encoder5",3,3,3)
        center = conv_block(encoder5,512,"center")
        decoder5 = decode(center,encoded5,256,"decoder5",3,3,3)
        decoder4 = decode(decoder5,encoded4,128,"decoder4",5,5,3)
        decoder3 = decode(decoder4,encoded3,64,"decoder3",5,5,3)
        decoder2 = decode(decoder3,encoded2,32,"decoder2",7,7,3)
        decoder1 = decode(decoder2,encoded1,16,"decoder1",7,7,3)
        
        with tf.variable_scope("legs",reuse=tf.AUTO_REUSE):
            leg4 = leg(decoder5,decoder4,name="leg4") 
            leg3 = leg(leg4,decoder3,name="leg3") 
            leg2 = leg(leg3,decoder2,name="leg2") 
            leg1 = leg(leg2,decoder1,name="leg1") 

        if softmax:
            output = conv_softmax(leg1,1,1,num_out,"output")
        else:
            output = conv_sig(leg1,1,1,num_out,"output")
        return output


def mnet3(input,num_out,name="mnet3",softmax=False,residual=True):
    if residual:
        encode=encoder_res_block
        decode=decoder_res_block
    else:
        encode=encoder_block
        decode=decoder_block

    with tf.variable_scope(name,reuse=tf.AUTO_REUSE):
        encoder1, encoded1 = encode(input,16,"encoder1",7,7,1)
        encoder2, encoded2 = encode(encoder1,32,"encoder2",5,5,1)
        encoder3, encoded3 = encode(encoder2,64,"encoder3",5,5,2)
        encoder4, encoded4 = encode(encoder3,128,"encoder4",3,3,2)
        center = conv_block(encoder4,512,"center")
        decoder4 = decode(center,encoded4,128,"decoder4",3,3,2)
        decoder3 = decode(decoder4,encoded3,64,"decoder3",5,5,2)
        decoder2 = decode(decoder3,encoded2,32,"decoder2",5,5,1)
        decoder1 = decode(decoder2,encoded1,16,"decoder1",7,7,1)
        
        with tf.variable_scope("legs",reuse=tf.AUTO_REUSE):
            leg3 = leg(decoder4,decoder3,name="leg3") 
            leg2 = leg(leg3,decoder2,name="leg2") 
            leg1 = leg(leg2,decoder1,name="leg1") 

        if softmax:
            output = conv_softmax(leg1,1,1,num_out,"output")
        else:
            output = conv_sig(leg1,1,1,num_out,"output")
        return output



def unet(input,num_out,name="unet",depth=5,base_num_filter=16,softmax=False,residual=True):
    if residual:
        encode=encoder_res_block
        decode=decoder_res_block
    else:
        encode=encoder_block
        decode=decoder_block

    with tf.variable_scope(name,reuse=tf.AUTO_REUSE):
        encoder=input
        res=[]
        for i in range(0,depth):
            encoder,encoded = encode(encoder,base_num_filter*2**i,"encoder{}".format(i),3,3,3)
            print(encoder,encoded)
            res.append(encoded)
            
        decoder = conv_block(encoder,base_num_filter*2**depth,"center")

        for i in range(depth-1,0-1,-1):
            decoder = decode(decoder,res.pop(),base_num_filter*2**i,"decoder{}".format(i),3,3,3)
            print(decoder)
        if softmax:
            output = conv_softmax(decoder,1,1,num_out,"output")
        else:
            output = conv_sig(decoder,1,1,num_out,"output")
        return output

def convnet(input,num_out):
    with tf.variable_scope("convnet",reuse=tf.AUTO_REUSE):
        encoder1,pool_ind1 = vgg_block(input,2,64,3,"block1")
        encoder2,pool_ind2 = vgg_block(encoder1,2,128,3,"block2")
        encoder3,pool_ind3 = vgg_block(encoder2,3,256,3,"block3")
        encoder4,pool_ind4 = vgg_block(encoder3,3,512,3,"block4")
        flattened = tf.reshape(encoder5,[-1,encoder5.shape[1]*encoder5.shape[2]*encoder5.shape[3]])
        dense_block0 = dense_block(flattened,4096,3,"dense_block0")
        out = dense(dense_block0,num_out,"out",activation=tf.nn.sigmoid)
        return out

def segnet(input,num_out,softmax=False,residual=True):
    if residual:
        encode=encoder_res_block_argmax
        decode=unpool_res_block
    else:
        encode=encoder_block_argmax
        decode=unpool_block

    with tf.variable_scope("segnet",reuse=tf.AUTO_REUSE):
        encoder1, encoded1 = encode(input,16,"encoder1",7,7,3)
        encoder2, encoded2 = encode(encoder1,32,"encoder2",7,7,3)
        encoder3, encoded3 = encode(encoder2,64,"encoder3",5,5,3)
        encoder4, encoded4 = encode(encoder3,128,"encoder4",5,5,3)
        encoder5, encoded5 = encoder_block_argmax(encoder4,256,"encoder5",3,3,3)
        center = conv_block(encoder5,256,"center")
        decoder5 = decode(center,encoded5,128,"decoder5",3,3,3)
        decoder4 = decode(decoder5,encoded4,64,"decoder4",5,5,3)
        decoder3 = decode(decoder4,encoded3,32,"decoder3",5,5,3)
        decoder2 = decode(decoder3,encoded2,16,"decoder2",7,7,3)
        decoder1 = decode(decoder2,encoded1,8,"decoder1",7,7,3)
        if softmax:
            output = conv_softmax(decoder1,1,1,num_out,"output")
        else:
            output = conv_sig(decoder1,1,1,num_out,"output")
        return output
